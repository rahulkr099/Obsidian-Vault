# MERN Backend Starter

A reusable backend foundation for MERN projects.

## Architecture

```text
Request
  ↓
Route
  ↓
Middleware
  ├── Request ID
  ├── Security
  ├── Rate limiting
  ├── Validation
  └── Authentication / Authorization
  ↓
Controller
  ↓
Service
  ↓
Repository
  ↓
Mongoose Model
  ↓
MongoDB
```

### Responsibilities

- **Routes** — connect endpoints, middleware and controllers.
- **Controllers** — HTTP concerns only.
- **Services** — business rules and orchestration.
- **Repositories** — database access only.
- **Models** — MongoDB schema definitions.
- **Validation** — Joi request validation.
- **Middlewares** — authentication, authorization, security, rate limiting, logging and error handling.
- **Utils** — reusable infrastructure helpers.
- **Constants** — roles and shared messages.

## Included

- Express + MongoDB + Mongoose
- JWT access tokens
- Hashed refresh tokens
- HttpOnly refresh cookie
- Short-lived access cookie plus Authorization-header support
- Password reset flow
- Role middleware / RBAC foundation
- Helmet, HPP, Mongo sanitization and HTML sanitization
- Explicit CORS allow-list middleware
- Global and auth-specific rate limiting
- Joi validation with unknown-field stripping
- Request IDs
- Central error handling
- Graceful SIGTERM/SIGINT shutdown
- Health endpoint
- Jest + Supertest starter tests
- Development and production Dockerfiles
- Docker Compose with MongoDB
- EJS email templates
- Environment validation
- Consistent API response helper

## Quick start

```bash
cp .env.example .env
```

Generate secrets:

```bash
openssl rand -hex 32
openssl rand -hex 32
```

Put the two generated values into `.env`.

Install and run:

```bash
npm install
npm run dev
```

API: `http://localhost:3000`

Health check: `GET /healthz`

## Docker development

```bash
cp .env.example .env
docker compose up --build
```

## Tests

```bash
npm test
npm run test:watch
npm run test:coverage
```

## Authentication contract

### Signup

`POST /api/v1/auth/signup`

Public signup always creates a normal `user`. **Role is never accepted from public signup input.**

### Login

`POST /api/v1/auth/login`

- Access token: short-lived; returned in JSON and also set as an HttpOnly cookie.
- Refresh token: long-lived; set only as an HttpOnly cookie and stored hashed in MongoDB.

### Authenticated requests

Prefer:

```http
Authorization: Bearer <access-token>
```

The backend also accepts the access cookie.

### Refresh

`POST /api/v1/auth/refresh-token`

The refresh token is read from the HttpOnly cookie and rotated on every successful refresh.

### Logout

`POST /api/v1/auth/logout`

Revokes the stored refresh-token hash and clears auth cookies.

## Starting a new project from this starter

1. Copy or clone this repository.
2. Rename the package/project.
3. Create `.env` from `.env.example`.
4. Configure MongoDB and secrets.
5. Keep the infrastructure folders unchanged unless the project needs something different.
6. Add your domain feature under the same Route → Controller → Service → Repository → Model flow.
7. Add validation beside the feature.
8. Add integration tests for every important permission boundary.
9. Add Docker only when deployment/local containerization is useful.

Example feature:

```text
products/
  product.controller.js
  product.service.js
  product.repository.js
  product.validation.js
  product.routes.js
  product.model.js
```

For small projects, the existing layered folders are intentional. For large projects, you can later migrate to feature modules without changing the underlying responsibilities.

## Before production

- Set `NODE_ENV=production`.
- Use strong unique secrets.
- Set `COOKIE_SAME_SITE` deliberately for your deployment topology.
- If cookies are used cross-site (`SameSite=None`), add a deliberate CSRF strategy for state-changing endpoints.
- Configure a production MongoDB deployment.
- Configure SMTP or replace the mail adapter with your provider.
- Add OpenAPI/Swagger if the API is consumed by other teams.
- Add structured logging and centralized log storage.
- Add metrics/tracing when the project needs them.
- Add CI checks for tests, linting, dependency auditing and builds.

## Suggested project evolution

```text
Starter
  ↓
Feature modules
  ↓
Tests
  ↓
Docker
  ↓
CI/CD
  ↓
Observability
  ↓
Production security hardening
```
