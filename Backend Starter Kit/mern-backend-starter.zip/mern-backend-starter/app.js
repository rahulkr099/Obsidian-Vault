import express from "express";
import cookieParser from "cookie-parser";
import mongoSanitize from "express-mongo-sanitize";
import helmet from "helmet";
import hpp from "hpp";

import router from "./routes/index.js";
import { middleware } from "./middlewares/index.js";

const app = express();

// 1. Body parsing
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

// 2. CORS + security middleware
app.use(middleware.security.cors);
app.use(mongoSanitize());
app.use(middleware.security.sanitizeInput);
app.use(helmet());
app.use(hpp());

// 3. Request ID (before logging)
app.use(middleware.core.requestId);

// 4. Logging
app.use(middleware.core.logger);

// 5. Global rate limiter
app.use(middleware.security.globalLimiter);

// 6. Stricter rate limiter, applied only to auth routes
app.use("/api/v1/auth", middleware.security.authLimiter);

// 7. Versioned API routes
app.use("/api/v1", router);

// 8. Health check endpoint
app.get("/healthz", (req, res) => {
  res.status(200).json({
    success: true,
    message: "API is running",
    uptime: process.uptime(),
    timestamp: Date.now(),
    requestId: req.id,
  });
});

// 9. 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found",
    requestId: req.id,
  });
});

// 10. Central error handler (must be last)
app.use(middleware.core.errorHandler);

export default app;
