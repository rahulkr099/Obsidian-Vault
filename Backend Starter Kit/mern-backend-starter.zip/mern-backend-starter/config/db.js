import mongoose from "mongoose";

import { env } from "./env.js";

// Connect MongoDB
export const connectDB = async () => {
  try {
    await mongoose.connect(env.mongoUri, {
      autoIndex: env.nodeEnv !== "production",
    });

    console.log("MongoDB connected");
  } catch (error) {
    console.error("Database connection failed", error);

    process.exit(1);
  }
};

export const disconnectDB = async () => {
  await mongoose.connection.close();
};
