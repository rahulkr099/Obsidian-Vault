import dotenv from "dotenv";
import Joi from "joi";

dotenv.config();

const envSchema = Joi.object({
  NODE_ENV: Joi.string().valid("development", "test", "production").default("development"),
  PORT: Joi.number().port().default(3000),
  MONGO_URI: Joi.string().required(),
  ACCESS_TOKEN_SECRET: Joi.string().min(32).required(),
  REFRESH_TOKEN_SECRET: Joi.string().min(32).required(),
  ACCESS_TOKEN_EXPIRES_IN: Joi.string().default("15m"),
  REFRESH_TOKEN_EXPIRES_IN: Joi.string().default("7d"),
  FRONTEND_URL: Joi.string().uri().default("http://localhost:5173"),
  COOKIE_SAME_SITE: Joi.string().valid("strict", "lax", "none").default("lax"),
  SMTP_HOST: Joi.string().allow(""),
  SMTP_PORT: Joi.number().port().default(587),
  SMTP_SECURE: Joi.boolean().truthy("true").falsy("false").default(false),
  SMTP_USER: Joi.string().allow(""),
  SMTP_PASSWORD: Joi.string().allow(""),
}).unknown();

const { value, error } = envSchema.validate(process.env, { abortEarly: false });

if (error && process.env.NODE_ENV !== "test") {
  console.error("Environment validation failed:\n" + error.details.map((d) => `- ${d.message}`).join("\n"));
  process.exit(1);
}

export const env = {
  nodeEnv: value.NODE_ENV || "test",
  port: Number(value.PORT) || 3000,
  mongoUri: value.MONGO_URI,
  accessTokenSecret: value.ACCESS_TOKEN_SECRET,
  refreshTokenSecret: value.REFRESH_TOKEN_SECRET,
  accessTokenExpiresIn: value.ACCESS_TOKEN_EXPIRES_IN || "15m",
  refreshTokenExpiresIn: value.REFRESH_TOKEN_EXPIRES_IN || "7d",
  frontendUrl: value.FRONTEND_URL || "http://localhost:5173",
  cookieSameSite: value.COOKIE_SAME_SITE || "lax",
  smtp: {
    host: value.SMTP_HOST,
    port: Number(value.SMTP_PORT) || 587,
    secure: Boolean(value.SMTP_SECURE),
    user: value.SMTP_USER,
    password: value.SMTP_PASSWORD,
  },
};

export default env;
