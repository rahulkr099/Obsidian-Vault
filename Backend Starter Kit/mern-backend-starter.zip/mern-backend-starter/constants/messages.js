export const MESSAGES = {
  COMMON: {
    SUCCESS: "Success",
    VALIDATION_FAILED: "Validation failed",
    ROUTE_NOT_FOUND: "Route not found",
  },
  AUTH: {
    SIGNUP_SUCCESS: "User created successfully",
    LOGIN_SUCCESS: "User logged in successfully",
    LOGOUT_SUCCESS: "User logged out successfully",
    TOKEN_REFRESHED: "Access token refreshed successfully",
    LOGGED_IN: "User is logged in",
    USER_EXISTS: "User already exists",
    INVALID_CREDENTIALS: "Incorrect email or password",
    TOKEN_MISSING: "Authentication token missing",
    TOKEN_INVALID: "Invalid or expired token",
    REFRESH_TOKEN_MISSING: "Refresh token missing",
    REFRESH_TOKEN_INVALID: "Invalid or expired refresh token",
  },
  PASSWORD: {
    RESET_EMAIL_SENT: "Check your email for the reset link",
    RESET_SUCCESS: "Password reset successful",
    EMAIL_NOT_REGISTERED: "Email is not registered",
    TOKEN_INVALID: "Invalid or expired reset token",
    TOKEN_EXPIRED: "Reset token expired",
    MISMATCH: "Passwords do not match",
  },
  USER: {
    NOT_FOUND: "User not found",
    PROFILE_UPDATED: "Profile updated successfully",
  },
};

export default MESSAGES;
