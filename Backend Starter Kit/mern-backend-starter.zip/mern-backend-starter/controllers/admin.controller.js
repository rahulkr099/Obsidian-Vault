import { asyncHandler, ok } from "../utils/index.js";

export const dashboard = asyncHandler(async (req, res) => {
  return ok(res, {
    message: "Admin authorization is working",
    data: { userId: req.user.id, role: req.user.role },
  });
});
