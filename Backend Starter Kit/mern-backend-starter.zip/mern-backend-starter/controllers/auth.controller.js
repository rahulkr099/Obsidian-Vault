import * as authService from "../services/auth.service.js";
import { asyncHandler, AppError, verifyAccessTokenJwt, ok } from "../utils/index.js";
import { MESSAGES } from "../constants/messages.js";
import { env } from "../config/env.js";

const refreshCookieOptions = () => ({
  httpOnly: true,
  secure: env.nodeEnv === "production",
  sameSite: env.cookieSameSite,
  maxAge: 7 * 24 * 60 * 60 * 1000,
  path: "/api/v1/auth",
});

const clearRefreshCookieOptions = () => ({
  ...refreshCookieOptions(),
  maxAge: undefined,
  expires: new Date(0),
});

export const signup = asyncHandler(async (req, res) => {
  const user = await authService.signup(req.body);
  return ok(res, { statusCode: 201, message: MESSAGES.AUTH.SIGNUP_SUCCESS, data: user });
});

export const login = asyncHandler(async (req, res) => {
  const result = await authService.login(req.body);

  // Only the refresh token is kept in an HttpOnly cookie.
  // The access token is returned to the client so it can be sent explicitly
  // as `Authorization: Bearer <token>`, which reduces CSRF exposure.
  res.cookie("refreshToken", result.refreshToken, refreshCookieOptions());

  return ok(res, {
    message: MESSAGES.AUTH.LOGIN_SUCCESS,
    data: { user: result.user, accessToken: result.accessToken },
  });
});

export const logout = asyncHandler(async (req, res) => {
  await authService.logout(req.user?.id);
  res.clearCookie("refreshToken", clearRefreshCookieOptions());
  return ok(res, { message: MESSAGES.AUTH.LOGOUT_SUCCESS });
});

export const refreshAccessToken = asyncHandler(async (req, res) => {
  const tokens = await authService.refreshAccessToken(req.cookies?.refreshToken);
  res.cookie("refreshToken", tokens.refreshToken, refreshCookieOptions());
  return ok(res, {
    message: MESSAGES.AUTH.TOKEN_REFRESHED,
    data: { accessToken: tokens.accessToken },
  });
});

export const authStatus = asyncHandler(async (req, res) => {
  const authorization = req.headers.authorization;
  const token = authorization?.startsWith("Bearer ") ? authorization.slice(7) : null;

  if (!token) throw new AppError(MESSAGES.AUTH.TOKEN_MISSING, 401);

  try {
    const decoded = verifyAccessTokenJwt(token);
    return ok(res, { message: MESSAGES.AUTH.LOGGED_IN, data: { user: decoded } });
  } catch {
    throw new AppError(MESSAGES.AUTH.TOKEN_INVALID, 401);
  }
});
