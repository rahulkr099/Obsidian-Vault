import { asyncHandler, ok } from "../utils/index.js";
import * as passwordService from "../services/password.service.js";
import { MESSAGES } from "../constants/messages.js";

export const resetPasswordToken = asyncHandler(async (req, res) => {
  await passwordService.generateResetToken(req.body.email);
  return ok(res, { message: MESSAGES.PASSWORD.RESET_EMAIL_SENT });
});

export const resetPassword = asyncHandler(async (req, res) => {
  await passwordService.resetPassword({
    email: req.body.email,
    password: req.body.password,
    confirmPassword: req.body.confirmPassword,
    token: req.query.token,
  });
  return ok(res, { message: MESSAGES.PASSWORD.RESET_SUCCESS });
});
