import { asyncHandler, AppError, ok } from "../utils/index.js";
import * as userRepository from "../repositories/user.repository.js";
import { MESSAGES } from "../constants/messages.js";

export const me = asyncHandler(async (req, res) => {
  const user = await userRepository.findUserByIdRepo(req.user.id);
  if (!user) throw new AppError(MESSAGES.USER.NOT_FOUND, 404);

  return ok(res, { data: {
    id: user._id,
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    role: user.role,
  }});
});
