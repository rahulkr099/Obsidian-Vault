# Backend Architecture

## Request lifecycle

```text
Client
  ↓
CORS
  ↓
Security middleware
  ↓
Request ID
  ↓
Logger
  ↓
Rate limiter
  ↓
Route
  ↓
Authentication / Authorization
  ↓
Validation
  ↓
Controller
  ↓
Service
  ↓
Repository
  ↓
Mongoose Model
  ↓
MongoDB
```

## Layer rules

### Routes
Wire middleware and controllers. No business logic.

### Controllers
Read HTTP input, call services, return HTTP responses. Do not query Mongoose directly.

### Services
Contain business rules, orchestration and permission-sensitive decisions.

### Repositories
Contain database operations only. Keep them easy to test and replace.

### Models
Define persistence shape, indexes and MongoDB constraints.

## Feature addition recipe

When adding a feature, follow:

```text
model
  ↓
repository
  ↓
service
  ↓
controller
  ↓
validation
  ↓
route
  ↓
test
```

For example:

```text
products/
  Product model
  Product repository
  Product service
  Product controller
  Product validation
  Product routes
  Integration tests
```

## Authentication model

- Access token is short-lived and sent explicitly as `Authorization: Bearer ...`.
- Refresh token is long-lived, stored only in an HttpOnly cookie and hashed in MongoDB.
- Refresh tokens are rotated on successful refresh.
- Password reset clears the stored refresh token hash, forcing re-authentication.
- Public signup always creates the `user` role. Admin is never accepted from public signup input.

## Security model

Baseline middleware includes:

- Helmet
- HPP
- Mongo query sanitization
- HTML/string sanitization
- CORS allow-list
- Global and auth-specific rate limits
- Joi validation with unknown-field stripping
- Authorization middleware
- Centralized error handling
- Request IDs

If `COOKIE_SAME_SITE=none` is required by your deployment, keep the trusted-origin check on cookie-based refresh operations and consider a full CSRF strategy for any future cookie-authenticated state-changing endpoint.
