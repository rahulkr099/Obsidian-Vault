# New Project Bootstrap

Use this starter as the infrastructure layer, then add the project's domain features.

## 1. Copy

```bash
cp -r mern-backend-starter my-project-backend
cd my-project-backend
rm -rf .git
```

## 2. Identity

Update:

- `package.json` name and description
- `README.md`
- `.env.example`

## 3. Environment

```bash
cp .env.example .env
openssl rand -hex 32
openssl rand -hex 32
```

## 4. Run

```bash
npm install
npm run dev
```

## 5. Add a feature

Create its model, repository, service, controller, validation and route.

Do not put database calls in controllers.

## 6. Test the feature

At minimum test:

- happy path
- validation failure
- unauthenticated request
- unauthorized request
- resource ownership
- not-found behavior
- important business rules

## 7. Production pass

Before deployment:

- configure production secrets
- configure MongoDB
- configure frontend origin
- decide SameSite/CSRF strategy
- configure email provider if needed
- run tests and coverage
- build Docker image
- add CI/CD
- add logs/metrics/tracing as needed
