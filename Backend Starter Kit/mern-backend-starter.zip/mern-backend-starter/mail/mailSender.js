import nodemailer from "nodemailer";

import { env } from "../config/env.js";

export const mailSender = async (email, title, body, text) => {
  try {
    const transporter = nodemailer.createTransport({
      host: env.smtp.host,
      port: env.smtp.port,
      secure: env.smtp.secure,
      auth: {
        user: env.smtp.user,
        pass: env.smtp.password,
      },
    });

    const info = await transporter.sendMail({
      from: env.smtp.user,
      to: email,
      subject: title,
      text: text || "",
      html: body,
    });

    return info;
  } catch (error) {
    console.error(error);
    throw error;
  }
};
