import ejs from "ejs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const renderTemplate = async (templateName, data) => {
  // Old code built this path as process.cwd()/src/mail/templates/..., but
  // there is no src/ directory in this project, so the file could never be
  // found. Using __dirname (relative to this file) makes it correct
  // regardless of the working directory the process is started from.
  const templatePath = path.join(__dirname, "templates", `${templateName}.ejs`);

  return ejs.renderFile(templatePath, data);
};
