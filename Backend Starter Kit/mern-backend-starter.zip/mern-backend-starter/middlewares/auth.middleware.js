import { asyncHandler, AppError, verifyAccessTokenJwt } from "../utils/index.js";
import { MESSAGES } from "../constants/messages.js";

export const authMiddleware = asyncHandler(async (req, res, next) => {
  const authorization = req.headers.authorization;
  const bearerToken = authorization?.startsWith("Bearer ")
    ? authorization.slice(7)
    : null;
  const accessToken = bearerToken || req.cookies?.accessToken;

  if (!accessToken) throw new AppError(MESSAGES.AUTH.TOKEN_MISSING, 401);

  try {
    req.user = verifyAccessTokenJwt(accessToken);
  } catch {
    throw new AppError(MESSAGES.AUTH.TOKEN_INVALID, 401);
  }

  next();
});

export default authMiddleware;
