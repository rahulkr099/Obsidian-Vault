function errorHandler(err, req, res, next) {
  const statusCode = err.statusCode || 500;

  // Don't leak stack traces / internals to the client, but do log them.
  console.error(`[${req.id}]`, err);

  res.status(statusCode).json({
    success: false,
    message: err.message || "Internal Server Error",
    errors: err.errors || [],
    requestId: req.id,
  });
}

export default errorHandler;
