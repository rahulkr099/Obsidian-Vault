import errorHandler from "./error.middleware.js";
import logger from "./logger.middleware.js";
import requestId from "./requestId.middleware.js";

import { globalLimiter, authLimiter } from "./security/rateLimiter.middleware.js";

import sanitizeInput from "./security/sanitize.middleware.js";
import validate from "./security/validate.middleware.js";
import { requireTrustedOrigin } from "./security/origin.middleware.js";
import { corsMiddleware } from "./security/cors.middleware.js";

import { authMiddleware } from "./auth.middleware.js";
import { requireRole } from "./role.middleware.js";

export const middleware = {
  security: { globalLimiter, authLimiter, sanitizeInput, validate, requireTrustedOrigin, cors: corsMiddleware },
  core: { logger, requestId, errorHandler },
  auth: { authMiddleware, requireRole },
};

export default middleware;
