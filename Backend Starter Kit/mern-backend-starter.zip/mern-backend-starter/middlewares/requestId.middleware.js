import { v4 as uuidv4 } from "uuid";

function requestId(req, res, next) {
  const id = uuidv4();

  req.id = id;
  res.setHeader("X-Request-Id", id);

  next();
}

export default requestId;
