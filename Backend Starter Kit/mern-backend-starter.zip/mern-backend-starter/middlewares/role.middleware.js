import { AppError } from "../utils/index.js";

// Authentication answers "who are you?" (auth.middleware.js).
// Authorization answers "what are you allowed to do?" (this file).
// Use after authMiddleware, e.g.:
//   router.delete("/:id", authMiddleware, requireRole("admin"), controller.remove);
export const requireRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return next(new AppError("Authentication required", 401));
    }

    if (!allowedRoles.includes(req.user.role)) {
      return next(new AppError("You do not have permission to perform this action", 403));
    }

    next();
  };
};

export default requireRole;
