import { env } from "../../config/env.js";

export const corsMiddleware = (req, res, next) => {
  const origin = req.headers.origin;

  if (origin && origin === env.frontendUrl) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,PATCH,PUT,DELETE,OPTIONS");
  }

  if (req.method === "OPTIONS") {
    if (origin !== env.frontendUrl) return res.status(403).json({ success: false, message: "CORS origin denied" });
    return res.sendStatus(204);
  }

  next();
};
