import { AppError } from "../../utils/index.js";
import { env } from "../../config/env.js";

// Cookie-based endpoints should not accept cross-site state-changing requests.
// This is a lightweight Origin check; keep it enabled when using SameSite=None.
export const requireTrustedOrigin = (req, res, next) => {
  if (env.nodeEnv !== "production" && !req.headers.origin) return next();

  const origin = req.headers.origin;
  if (!origin || origin !== env.frontendUrl) {
    throw new AppError("Untrusted request origin", 403);
  }

  next();
};
