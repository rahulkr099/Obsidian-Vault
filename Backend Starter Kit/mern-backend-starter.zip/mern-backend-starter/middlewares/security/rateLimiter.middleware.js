// Import express-rate-limit package
import rateLimit from "express-rate-limit";

// Global rate limiter - applies to every request
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per IP per window
  standardHeaders: true,
  legacyHeaders: false,
});

// Stricter limiter for auth routes (login/signup are common brute-force targets)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
});

export { globalLimiter, authLimiter };
