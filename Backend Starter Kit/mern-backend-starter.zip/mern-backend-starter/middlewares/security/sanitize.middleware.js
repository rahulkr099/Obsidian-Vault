// Import cleanString function from utils/sanitize.js.
// NOTE: the original code imported from the bare specifier "@utils/sanitize",
// but no path alias was ever configured (no jsconfig/tsconfig "paths" and no
// package.json "imports" field), so this import would fail at runtime.
import cleanString from "../../utils/sanitize.js";

// Middleware function to sanitize user input
function sanitizeInput(req, res, next) {
  // Function to sanitize all string values inside an object
  const sanitizeObject = (obj) => {
    Object.keys(obj).forEach((key) => {
      if (typeof obj[key] === "string") {
        obj[key] = cleanString(obj[key]);
      }
    });
  };

  if (req.body) sanitizeObject(req.body);
  if (req.query) sanitizeObject(req.query);
  if (req.params) sanitizeObject(req.params);

  next();
}

export default sanitizeInput;
