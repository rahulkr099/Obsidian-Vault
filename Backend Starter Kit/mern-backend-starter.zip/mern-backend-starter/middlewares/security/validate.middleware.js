// Create a reusable validation middleware function
function validate(schema) {
  return (req, res, next) => {
    const { value, error } = schema.validate(
      {
        body: req.body,
        query: req.query,
        params: req.params,
      },
      {
        abortEarly: false, // show all validation errors, not just the first
        stripUnknown: true, // drop fields not defined in the schema
      }
    );

    if (error) {
      const errors = error.details.map((d) => d.message.replace(/"/g, ""));

      return res.status(400).json({
        success: false,
        message: "Validation failed",
        errors,
        requestId: req.id,
      });
    }

    req.body = value.body;
    req.query = value.query;
    req.params = value.params;

    next();
  };
}

// Exported both ways: some routes historically imported this as a named
// export (`import { validate } ...`) and others as default
// (`import validate ...`). Supporting both here avoids that class of bug
// recurring - but new code should prefer the default export.
export { validate };
export default validate;
