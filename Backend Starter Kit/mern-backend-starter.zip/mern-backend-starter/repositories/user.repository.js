import User from "../models/user.model.js";

export const findUserByEmailRepo = async (email, { withPassword = false } = {}) => {
  const query = User.findOne({ email });
  if (withPassword) query.select("+password");
  return query;
};

export const findUserByIdRepo = async (userId, { withRefreshToken = false } = {}) => {
  const query = User.findById(userId);
  if (withRefreshToken) query.select("+refreshTokenHash");
  return query;
};

export const createUserRepo = (userData) => User.create(userData);

export const updateRefreshTokenHashRepo = (userId, refreshTokenHash) =>
  User.findByIdAndUpdate(userId, { refreshTokenHash }, { new: true });

export const removeRefreshTokenRepo = (userId) =>
  User.findByIdAndUpdate(userId, { $unset: { refreshTokenHash: 1 } }, { new: true });

export const saveResetTokenRepo = (email, resetPasswordToken, resetPasswordExpires) =>
  User.findOneAndUpdate(
    { email },
    { resetPasswordToken, resetPasswordExpires },
    { new: true }
  );

export const findUserByResetTokenRepo = (email, resetPasswordToken) =>
  User.findOne({ email, resetPasswordToken }).select(
    "+resetPasswordToken +resetPasswordExpires +password"
  );

export const updatePasswordRepo = (email, resetPasswordToken, password) =>
  User.findOneAndUpdate(
    { email, resetPasswordToken },
    {
      password,
      $unset: {
        resetPasswordToken: 1,
        resetPasswordExpires: 1,
        refreshTokenHash: 1,
      },
    },
    { new: true }
  );
