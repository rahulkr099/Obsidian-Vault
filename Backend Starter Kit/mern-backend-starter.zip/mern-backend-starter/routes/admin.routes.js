import express from "express";
import { authMiddleware } from "../middlewares/auth.middleware.js";
import { requireRole } from "../middlewares/role.middleware.js";
import { dashboard } from "../controllers/admin.controller.js";
import { ROLES } from "../constants/roles.js";

const router = express.Router();

router.get("/dashboard", authMiddleware, requireRole(ROLES.ADMIN), dashboard);

export default router;
