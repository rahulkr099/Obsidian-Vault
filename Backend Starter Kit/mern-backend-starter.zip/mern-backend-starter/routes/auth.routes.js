import express from "express";
import * as authController from "../controllers/auth.controller.js";
import * as passwordController from "../controllers/password.controller.js";
import {
  signupSchema,
  loginSchema,
  resetPasswordTokenSchema,
  resetPasswordSchema,
} from "../validations/auth.validation.js";
import { validate } from "../middlewares/security/validate.middleware.js";
import { authMiddleware } from "../middlewares/auth.middleware.js";
import { requireTrustedOrigin } from "../middlewares/security/origin.middleware.js";

const router = express.Router();

router.post("/signup", validate(signupSchema), authController.signup);
router.post("/login", validate(loginSchema), authController.login);
router.post("/logout", authMiddleware, authController.logout);
router.post("/refresh-token", requireTrustedOrigin, authController.refreshAccessToken);
router.get("/status", authMiddleware, authController.authStatus);
router.post(
  "/reset-password-token",
  validate(resetPasswordTokenSchema),
  passwordController.resetPasswordToken
);
router.post(
  "/reset-password",
  validate(resetPasswordSchema),
  passwordController.resetPassword
);

export default router;
