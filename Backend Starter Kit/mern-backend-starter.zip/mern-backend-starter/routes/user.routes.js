import express from "express";
import { authMiddleware } from "../middlewares/auth.middleware.js";
import { me } from "../controllers/user.controller.js";

const router = express.Router();

router.use(authMiddleware);
router.get("/me", me);

export default router;
