import app from "./app.js";
import { connectDB, disconnectDB } from "./config/db.js";
import { env } from "./config/env.js";

let server;

async function startServer() {
  await connectDB();

  server = app.listen(env.port, () => {
    console.log(`Server running on port ${env.port} (${env.nodeEnv})`);
  });
}

// Close the HTTP server and DB connection cleanly on shutdown signals
// (Docker, Kubernetes, and platforms like Render all send SIGTERM before
// killing a container).
async function gracefulShutdown(signal) {
  console.log(`\n${signal} received: shutting down gracefully`);

  if (server) {
    server.close(async () => {
      console.log("HTTP server closed");
      await disconnectDB();
      console.log("MongoDB connection closed");
      process.exit(0);
    });

    // Force-exit if connections don't close in time
    setTimeout(() => process.exit(1), 10000).unref();
  } else {
    process.exit(0);
  }
}

process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => gracefulShutdown("SIGINT"));

startServer();
