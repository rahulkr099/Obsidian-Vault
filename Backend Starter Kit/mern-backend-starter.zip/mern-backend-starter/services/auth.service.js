import bcrypt from "bcrypt";
import * as userRepository from "../repositories/user.repository.js";
import { AppError } from "../utils/index.js";
import {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshTokenJwt,
} from "../utils/generateToken.js";
import { MESSAGES } from "../constants/messages.js";
import { ROLES } from "../constants/roles.js";

const toSanitizedUser = (user) => ({
  id: user._id,
  firstName: user.firstName,
  lastName: user.lastName,
  email: user.email,
  role: user.role,
});

const buildTokenPayload = (user) => ({
  id: user._id,
  firstName: user.firstName,
  lastName: user.lastName,
  email: user.email,
  role: user.role,
});

export const signup = async ({ firstName, lastName, email, password }) => {
  const normalizedEmail = email.trim().toLowerCase();
  const existingUser = await userRepository.findUserByEmailRepo(normalizedEmail);

  if (existingUser) throw new AppError(MESSAGES.AUTH.USER_EXISTS, 400);

  const hashedPassword = await bcrypt.hash(password, 12);

  const user = await userRepository.createUserRepo({
    firstName: firstName.trim(),
    lastName: lastName.trim(),
    email: normalizedEmail,
    password: hashedPassword,
    role: ROLES.USER,
  });

  return toSanitizedUser(user);
};

export const login = async ({ email, password }) => {
  const normalizedEmail = email.trim().toLowerCase();
  const user = await userRepository.findUserByEmailRepo(normalizedEmail, { withPassword: true });

  if (!user || !(await bcrypt.compare(password, user.password))) {
    throw new AppError(MESSAGES.AUTH.INVALID_CREDENTIALS, 401);
  }

  const accessToken = generateAccessToken(buildTokenPayload(user));
  const refreshToken = generateRefreshToken({ id: user._id, email: user.email });
  const refreshTokenHash = await bcrypt.hash(refreshToken, 12);

  await userRepository.updateRefreshTokenHashRepo(user._id, refreshTokenHash);

  return { accessToken, refreshToken, user: toSanitizedUser(user) };
};

export const logout = async (userId) => {
  if (userId) await userRepository.removeRefreshTokenRepo(userId);
};

export const refreshAccessToken = async (incomingRefreshToken) => {
  if (!incomingRefreshToken) throw new AppError(MESSAGES.AUTH.REFRESH_TOKEN_MISSING, 401);

  let decodedToken;
  try {
    decodedToken = verifyRefreshTokenJwt(incomingRefreshToken);
  } catch {
    throw new AppError(MESSAGES.AUTH.REFRESH_TOKEN_INVALID, 401);
  }

  const user = await userRepository.findUserByIdRepo(decodedToken.id, { withRefreshToken: true });
  if (!user?.refreshTokenHash) throw new AppError(MESSAGES.AUTH.REFRESH_TOKEN_INVALID, 401);

  const isValid = await bcrypt.compare(incomingRefreshToken, user.refreshTokenHash);
  if (!isValid) throw new AppError(MESSAGES.AUTH.REFRESH_TOKEN_INVALID, 401);

  const accessToken = generateAccessToken(buildTokenPayload(user));
  const refreshToken = generateRefreshToken({ id: user._id, email: user.email });
  const refreshTokenHash = await bcrypt.hash(refreshToken, 12);

  await userRepository.updateRefreshTokenHashRepo(user._id, refreshTokenHash);

  return { accessToken, refreshToken };
};
