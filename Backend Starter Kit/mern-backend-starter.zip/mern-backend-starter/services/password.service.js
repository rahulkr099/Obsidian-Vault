import bcrypt from "bcrypt";
import crypto from "crypto";

import * as userRepository from "../repositories/user.repository.js";
import { renderTemplate } from "../mail/renderTemplate.js";
import { mailSender } from "../mail/mailSender.js";
import { AppError } from "../utils/index.js";
import { env } from "../config/env.js";
import { MESSAGES } from "../constants/messages.js";

// Generate reset token and email it to the user
export const generateResetToken = async (email) => {
  const normalizedEmail = email.trim().toLowerCase();

  const user = await userRepository.findUserByEmailRepo(normalizedEmail);

  if (!user) {
    throw new AppError(MESSAGES.PASSWORD.EMAIL_NOT_REGISTERED, 404);
  }

  const resetPasswordToken = crypto.randomBytes(20).toString("hex");

  const hashedToken = crypto.createHash("sha256").update(resetPasswordToken).digest("hex");

  await userRepository.saveResetTokenRepo(
    normalizedEmail,
    hashedToken,
    Date.now() + 15 * 60 * 1000 // 15 minutes
  );

  const resetUrl = `${env.frontendUrl}/reset-password?token=${resetPasswordToken}&email=${encodeURIComponent(
    normalizedEmail
  )}`;

  const html = await renderTemplate("resetPassword", { email: normalizedEmail, resetUrl });

  await mailSender(normalizedEmail, "Password Reset", html);

  return true;
};

// Reset password using the token issued above
export const resetPassword = async ({ email, password, confirmPassword, token }) => {
  if (password !== confirmPassword) {
    throw new AppError(MESSAGES.PASSWORD.MISMATCH, 400);
  }

  const normalizedEmail = email.trim().toLowerCase();

  const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

  const user = await userRepository.findUserByResetTokenRepo(normalizedEmail, hashedToken);

  if (!user) {
    throw new AppError(MESSAGES.PASSWORD.TOKEN_INVALID, 400);
  }

  if (user.resetPasswordExpires < Date.now()) {
    throw new AppError(MESSAGES.PASSWORD.TOKEN_EXPIRED, 403);
  }

  const encryptedPassword = await bcrypt.hash(password, 12);

  await userRepository.updatePasswordRepo(normalizedEmail, hashedToken, encryptedPassword);

  return true;
};
