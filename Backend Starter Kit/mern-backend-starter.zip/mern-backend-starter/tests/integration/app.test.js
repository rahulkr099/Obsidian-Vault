import request from "supertest";
import app from "../../app.js";

describe("API smoke tests", () => {
  test("GET /healthz returns 200", async () => {
    const response = await request(app).get("/healthz");
    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);
    expect(response.body.requestId).toBeDefined();
  });

  test("unknown route returns 404", async () => {
    const response = await request(app).get("/api/v1/does-not-exist");
    expect(response.status).toBe(404);
    expect(response.body.success).toBe(false);
  });

  test("protected user route rejects anonymous request", async () => {
    const response = await request(app).get("/api/v1/users/me");
    expect(response.status).toBe(401);
    expect(response.body.success).toBe(false);
  });

  test("signup rejects an invalid password", async () => {
    const response = await request(app).post("/api/v1/auth/signup").send({
      firstName: "Test",
      lastName: "User",
      email: "test@example.com",
      password: "weak",
    });

    expect(response.status).toBe(400);
    expect(response.body.success).toBe(false);
    expect(response.body.errors.length).toBeGreaterThan(0);
  });
});
