// Small helpers so every endpoint returns the same JSON shape.
// success:  { success: true, message, data, requestId }
// error:    { success: false, message, errors, requestId }  (errors thrown as
//            AppError are formatted this way by middlewares/error.middleware.js)

export const ok = (res, { statusCode = 200, message = "Success", data = null, meta } = {}) => {
  const body = {
    success: true,
    message,
    data,
    requestId: res.req?.id,
  };

  if (meta) body.meta = meta;

  return res.status(statusCode).json(body);
};

export const created = (res, options = {}) => ok(res, { statusCode: 201, ...options });

export default { ok, created };
