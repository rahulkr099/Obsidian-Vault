// Create custom error class by extending built-in Error class
class AppError extends Error {
  // Constructor function with default values
  constructor(message = "Something went wrong", statusCode = 500, errors = []) {
    // Call parent Error class constructor
    super(message);

    // Set custom error class name
    this.name = "AppError";

    // Store HTTP status code
    this.statusCode = statusCode;

    // Store additional error details
    this.errors = errors;

    // Indicate request failed
    this.success = false;

    // Capture proper error stack trace
    Error.captureStackTrace(this, this.constructor);
  }
}

// Export AppError class
export default AppError;
