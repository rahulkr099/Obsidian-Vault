// Create a wrapper function for handling async errors
const asyncHandler = (fn) => {
  // Return middleware function
  return function (req, res, next) {
    // Execute async function and catch any errors
    return Promise.resolve(fn(req, res, next)).catch(next);
  };
};

// Export asyncHandler function
export default asyncHandler;
