import jwt from "jsonwebtoken";

import { env } from "../config/env.js";

// Short-lived token used to authenticate normal requests
export const generateAccessToken = (payload) => {
  return jwt.sign(payload, env.accessTokenSecret, {
    expiresIn: env.accessTokenExpiresIn,
  });
};

// Long-lived token used only to mint new access tokens
export const generateRefreshToken = (payload) => {
  return jwt.sign(payload, env.refreshTokenSecret, {
    expiresIn: env.refreshTokenExpiresIn,
  });
};

export const verifyAccessTokenJwt = (token) => {
  return jwt.verify(token, env.accessTokenSecret);
};

export const verifyRefreshTokenJwt = (token) => {
  return jwt.verify(token, env.refreshTokenSecret);
};
