// Import sanitize-html package
import sanitizeHtml from "sanitize-html";

// Function to clean and sanitize input string
function cleanString(value) {
  // Check if value is not a string
  if (typeof value !== "string") return value;

  // Remove unwanted HTML and trim extra spaces
  return sanitizeHtml(value.trim(), {
    // Do not allow any HTML tags
    allowedTags: [],

    // Do not allow any HTML attributes
    allowedAttributes: {},
  });
}

// Export cleanString function
export default cleanString;
