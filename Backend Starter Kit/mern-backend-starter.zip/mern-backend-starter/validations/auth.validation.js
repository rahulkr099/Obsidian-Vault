import Joi from "joi";

const PASSWORD_PATTERN = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

export const signupSchema = Joi.object({
  body: Joi.object({
    firstName: Joi.string().min(2).max(50).trim().required(),
    lastName: Joi.string().min(2).max(50).trim().required(),
    email: Joi.string().email().lowercase().trim().required(),
    password: Joi.string().min(8).pattern(PASSWORD_PATTERN).required().messages({
      "string.pattern.base":
        "Password must include at least one uppercase letter, one lowercase letter, one number, and one special character",
    }),
  }),
});

export const loginSchema = Joi.object({
  body: Joi.object({
    email: Joi.string().email().lowercase().trim().required(),
    password: Joi.string().min(8).required(),
  }),
});

export const resetPasswordTokenSchema = Joi.object({
  body: Joi.object({
    email: Joi.string().email().lowercase().trim().required(),
  }),
});

export const resetPasswordSchema = Joi.object({
  query: Joi.object({
    token: Joi.string().hex().length(40).required(),
  }),
  body: Joi.object({
    email: Joi.string().email().lowercase().trim().required(),
    password: Joi.string().min(8).pattern(PASSWORD_PATTERN).required(),
    confirmPassword: Joi.string().valid(Joi.ref("password")).required().messages({
      "any.only": "Passwords do not match",
    }),
  }),
});
